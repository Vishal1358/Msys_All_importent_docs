'''
l1 = ["siya","priya","jiya"]
l2 = [170,120,130]
'''

